<?php
session_start();
include("config/db.php");

// CHECK LOGIN
if(!isset($_SESSION['user'])){
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

// VALIDATE INPUT
$video_id = $_POST['video_id'] ?? 0;
$comment = trim($_POST['comment'] ?? '');

if($video_id && $comment != ''){

    // PREPARED STATEMENT (SAFE)
    $stmt = $conn->prepare("INSERT INTO comments (video_id, user_id, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $video_id, $user_id, $comment);
    $stmt->execute();
}

// REDIRECT BACK
header("Location: workspace.php");
exit();