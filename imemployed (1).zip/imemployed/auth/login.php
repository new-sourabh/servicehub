<?php
session_start();
include("../config/db.php");

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    $user = $result->fetch_assoc();

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user'] = $user;

       if($user['role'] == 'provider'){
    header("Location: ../provider/dashboard.php");
       } else {
    header("Location: ../index.php");
       }
    } else {
        echo "Invalid Login!";
    }
}
?>

<link rel="stylesheet" href="../assets/css/style.css">

<div class="navbar">Job Portal</div>

<div class="container">
<h2>Login</h2>

<form method="POST">
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>

    <button name="login">Login</button>
</form>

<div class="link">
    <a href="register.php">Create Account</a>
</div>
</div>