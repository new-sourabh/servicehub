<?php
session_start();
include("../config/db.php");

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];
    $username = "@" . $_POST['username'];

    // DEFAULT IMAGE
    $profile_pic = "default.png";

    // IMAGE UPLOAD (IF USER SELECTS)
    if(!empty($_FILES['profile_pic']['name'])){
        $profile_pic = time() . "_" . $_FILES['profile_pic']['name'];
        $target = "../uploads/images/" . $profile_pic;

        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target);
    }

    // INSERT USER
    $stmt = $conn->prepare("INSERT INTO users (name,email,password,role,username,phone,location,profile_pic) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssss",$name,$email,$password,$role,$username,$phone,$location,$profile_pic);

    if($stmt->execute()){
        
        // AUTO LOGIN AFTER REGISTER
        $user_id = $stmt->insert_id;
        $result = $conn->query("SELECT * FROM users WHERE id='$user_id'");
        $user = $result->fetch_assoc();

        $_SESSION['user'] = $user;

        if($user['role'] == 'provider'){
    header("Location: ../provider/dashboard.php");
       } else {
    header("Location: ../index.php");
       }
        exit();
    } else {
        echo "Error: Username or Email already exists";
    }
}
?>

<link rel="stylesheet" href="../assets/css/style.css">

<div class="navbar">servicehub</div>

<div class="container">
<h2>Register</h2>

<form method="POST" enctype="multipart/form-data">

    <!-- IMAGE PREVIEW -->
    <div style="text-align:center;">
        <img id="preview" src="../uploads/images/default.png" 
             style="width:100px; height:100px; border-radius:50%; object-fit:cover; margin-bottom:10px;">
    </div>

    <input type="file" name="profile_pic" accept="image/*" onchange="previewImage(event)">

    <input type="text" name="name" placeholder="Full Name" required>
    <input type="text" name="username" placeholder="Username (without @)" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>

    <select name="role">
        <option value="user">User</option>
        <option value="provider">Provider</option>
    </select>

    <input type="text" name="phone" placeholder="Phone Number" required>
    <input type="text" name="location" placeholder="City (Amritsar, Ludhiana)" required>

    <button name="register">Register</button>
</form>

<div class="link">
    <a href="login.php">Already have account? Login</a>
</div>
</div>

<!-- IMAGE PREVIEW SCRIPT -->
<script>
function previewImage(event) {
    var reader = new FileReader();
    reader.onload = function(){
        document.getElementById('preview').src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}
</script>