<?php
session_start();
include("config/db.php");

$user_id = $_SESSION['user']['id'];

// GET USER
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

// UPDATE
if(isset($_POST['update'])){

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $location = $_POST['location'];

    // IMAGE UPLOAD
    if($_FILES['profile_pic']['name']){
        $img = $_FILES['profile_pic']['name'];
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], "uploads/images/".$img);

        $conn->query("UPDATE users SET profile_pic='$img' WHERE id='$user_id'");
        $_SESSION['user']['profile_pic'] = $img;
    }

    $conn->query("UPDATE users SET name='$name', phone='$phone', location='$location' WHERE id='$user_id'");

    header("Location: profile.php?id=".$user_id);
}
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="navbar">
    Edit Profile |
    <a href="profile.php?id=<?php echo $user_id; ?>">Back</a>
</div>

<div style="width:400px; margin:30px auto; background:white; padding:20px; border-radius:10px;">

<form method="POST" enctype="multipart/form-data">

    <label>Name</label><br>
    <input type="text" name="name" value="<?php echo $user['name']; ?>"><br><br>

    <label>Phone</label><br>
    <input type="text" name="phone" value="<?php echo $user['phone']; ?>"><br><br>

    <label>Location</label><br>
    <input type="text" name="location" value="<?php echo $user['location']; ?>"><br><br>

    <label>Profile Picture</label><br>
    <input type="file" name="profile_pic"><br><br>

    <button name="update" class="btn">Update Profile</button>

</form>

</div>