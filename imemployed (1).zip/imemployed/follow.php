<?php
session_start();
include("config/db.php");

if(!isset($_SESSION['user'])){
    echo "<script>alert('Please login first'); window.location='auth/login.php';</script>";
    exit();
}

$follower_id = $_SESSION['user']['id'];
$following_id = $_GET['user_id'];

// CHECK IF ALREADY FOLLOWING
$check = $conn->query("SELECT * FROM follows 
                       WHERE follower_id='$follower_id' AND following_id='$following_id'");

if($check->num_rows > 0){
    // UNFOLLOW
    $conn->query("DELETE FROM follows 
                  WHERE follower_id='$follower_id' AND following_id='$following_id'");
} else {
    // FOLLOW
    $conn->query("INSERT INTO follows (follower_id, following_id) 
                  VALUES ('$follower_id', '$following_id')");
}

header("Location: index.php");
?>