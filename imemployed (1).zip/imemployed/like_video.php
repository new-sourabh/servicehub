<?php
session_start();
include("config/db.php");

$user_id = $_SESSION['user']['id'];
$video_id = $_GET['video_id'];

// CHECK IF ALREADY LIKED
$check = $conn->query("SELECT * FROM video_likes 
                       WHERE user_id='$user_id' AND video_id='$video_id'");

if($check->num_rows > 0){
    // UNLIKE
    $conn->query("DELETE FROM video_likes 
                  WHERE user_id='$user_id' AND video_id='$video_id'");
} else {
    // LIKE
    $conn->query("INSERT INTO video_likes (user_id, video_id) 
                  VALUES ('$user_id', '$video_id')");
}

header("Location: workspace.php");
?>