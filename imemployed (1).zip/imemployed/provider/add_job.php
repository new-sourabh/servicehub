<?php
session_start();
include("../config/db.php");

$provider_id = $_SESSION['user']['id'];

if(isset($_POST['add_job'])){
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $contact = $_POST['contact'];
    $location = $_POST['location'];

    $stmt = $conn->prepare("INSERT INTO jobs (provider_id,title,description,category,price,contact,location) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("isssdss",$provider_id,$title,$desc,$category,$price,$contact,$location);
    $stmt->execute();

    echo "Work Added Successfully!";
}
?>
<link rel="stylesheet" href="../assets/css/style.css">

<div class="job-form-container">

    <h2>➕ Add New Service</h2>

    <form method="POST">

        <input type="text" name="title" placeholder="Work Title (Plumber, Designer)" required>

        <textarea name="description" placeholder="Describe your work" required></textarea>

        <input type="text" name="category" placeholder="Category">

        <input type="number" name="price" placeholder="Price">

        <input type="text" name="contact" placeholder="Phone">

        <input type="text" name="location" placeholder="City">

        <button name="add_job">Post Work</button>

    </form>

</div>