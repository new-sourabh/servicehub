<?php
session_start();
include("../config/db.php");

// SECURITY CHECK
if(!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'provider'){
    header("Location: ../auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$user_id = $user['id'];

// 🔥 STATS
$total_jobs = $conn->query("SELECT * FROM jobs WHERE provider_id='$user_id'")->num_rows;
$total_posts = $conn->query("SELECT * FROM videos WHERE user_id='$user_id'")->num_rows;
$followers = $conn->query("SELECT * FROM follows WHERE following_id='$user_id'")->num_rows;

// 🔥 RECENT DATA
$jobs = $conn->query("SELECT * FROM jobs WHERE provider_id='$user_id' ORDER BY id DESC LIMIT 3");
$posts = $conn->query("SELECT * FROM videos WHERE user_id='$user_id' ORDER BY id DESC LIMIT 3");
?>

<link rel="stylesheet" href="../assets/css/style.css">

<!-- NAVBAR -->
<div class="navbar">
    Provider Panel | Welcome <?php echo $user['name']; ?> |
    <a href="../auth/logout.php" style="color:white;">Logout</a>
</div>

<!-- DASHBOARD -->
<div class="dashboard-container">

    <h2>👨‍💼 Provider Dashboard</h2>

    <!-- STATS -->
    <div class="stats-box">

        <div class="stat">
            <h3><?php echo $total_jobs; ?></h3>
            <p>Services</p>
        </div>

        <div class="stat">
            <h3><?php echo $total_posts; ?></h3>
            <p>Posts</p>
        </div>

        <div class="stat">
            <h3><?php echo $followers; ?></h3>
            <p>Connections</p>
        </div>

    </div>

    <!-- ACTION BUTTONS -->
    <div class="dashboard-actions">
        <a href="add_job.php">➕ Add Work</a>
        <a href="upload_video.php">🎥 Upload Content</a>
        <a href="../index.php">🏠 Home</a>
    </div>

    <!-- RECENT SERVICES -->
    <h3>🛠 Your Services</h3>
    <div class="dash-cards">
        <?php while($job = $jobs->fetch_assoc()){ ?>
            <div class="dash-card">
                <b><?php echo $job['title']; ?></b>
                <p>₹<?php echo $job['price']; ?></p>
            </div>
        <?php } ?>
    </div>

    <!-- RECENT POSTS -->
    <h3>📸 Your Posts</h3>
    <div class="dash-cards">
        <?php while($p = $posts->fetch_assoc()){ ?>
            <div class="dash-card">
                <?php if($p['type'] == 'video'){ ?>
                    <video src="../uploads/videos/<?php echo $p['video_path']; ?>" muted></video>
                <?php } else { ?>
                    <img src="../uploads/images/<?php echo $p['video_path']; ?>">
                <?php } ?>
            </div>
        <?php } ?>
    </div>

</div>