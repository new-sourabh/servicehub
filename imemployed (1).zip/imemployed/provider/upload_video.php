<?php
session_start();
include("../config/db.php");

$user_id = $_SESSION['user']['id'];

if(isset($_POST['upload'])){

    $caption = $_POST['caption'];

    $file = $_FILES['file']['name'];
    $tmp = $_FILES['file']['tmp_name'];

    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

    $new_name = time() . "_" . $file;
    if(in_array($ext, ['mp4','webm','mov'])){
    $type = "video";
    $target = "../uploads/videos/" . $new_name;
    $db_path = $new_name;
} else {
    $type = "image";
    $target = "../uploads/images/" . $new_name;
    $db_path = $new_name;
}

    move_uploaded_file($tmp, $target);

    // CHECK TYPE
    if(in_array($ext, ['mp4','webm','mov'])){
        $type = "video";
    } else {
        $type = "image";
    }

    $stmt = $conn->prepare("INSERT INTO videos (user_id, video_path, caption, type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $db_path, $caption, $type);
    $stmt->execute();

    header("Location: dashboard.php");
}
?>

<link rel="stylesheet" href="../assets/css/style.css">

<div class="upload-container">

    <h2>📤 Upload Post</h2>

    <form method="POST" enctype="multipart/form-data">

        <input type="file" name="file" required>

        <input type="text" name="caption" placeholder="Write caption...">

        <button name="upload">Upload</button>

    </form>

</div>