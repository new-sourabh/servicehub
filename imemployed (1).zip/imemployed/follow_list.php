<?php
session_start();
include("config/db.php");

$user_id = $_SESSION['user']['id'];

// TYPE: followers OR following
$type = $_GET['type'] ?? 'following';

if($type == 'followers'){
    $query = "
        SELECT users.* FROM follows
        JOIN users ON follows.follower_id = users.id
        WHERE follows.following_id = '$user_id'
    ";
    $title = "👥 Your Followers";
} else {
    $query = "
        SELECT users.* FROM follows
        JOIN users ON follows.following_id = users.id
        WHERE follows.follower_id = '$user_id'
    ";
    $title = "👤 You Are Following";
}

$result = $conn->query($query);
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="navbar">
    <?php echo $title; ?> |
    <a href="index.php" style="color:white;">Home</a>
</div>

<div style="width:400px; margin:20px auto;">

<?php while($row = $result->fetch_assoc()){ ?>

<div class="follow-item" style="background:white; padding:10px; margin:10px; border-radius:10px; box-shadow:0 0 10px #ccc; display:flex; align-items:center; gap:10px;">

    <img src="uploads/images/<?php echo $row['profile_pic']; ?>" 
         style="width:50px; height:50px; border-radius:50%; object-fit:cover;">

    <div>
        <a href="profile.php?id=<?php echo $row['id']; ?>">
            <b><?php echo $row['username']; ?></b>
        </a>
        <p><?php echo $row['location']; ?></p>
    </div>

</div>

<?php } ?>

</div>