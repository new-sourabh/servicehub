<?php
session_start();
include("config/db.php");

if(!isset($_SESSION['user'])){
    echo "<script>alert('Please login first'); window.location='auth/login.php';</script>";
    exit();
}

$my_id = $_SESSION['user']['id'];
$other_id = $_GET['user_id'];

// OTHER USER
$user = $conn->query("SELECT * FROM users WHERE id='$other_id'")->fetch_assoc();

// SEND MESSAGE
if(isset($_POST['send'])){
    $msg = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?,?,?)");
    $stmt->bind_param("iis", $my_id, $other_id, $msg);
    $stmt->execute();

    header("Location: chat.php?user_id=".$other_id);
    exit();
}

// FETCH MESSAGES
$messages = $conn->query("
    SELECT * FROM messages 
    WHERE (sender_id='$my_id' AND receiver_id='$other_id')
       OR (sender_id='$other_id' AND receiver_id='$my_id')
    ORDER BY id ASC
");
?>

<link rel="stylesheet" href="assets/css/style.css">

<!-- NAVBAR -->
<div class="navbar">
    Chat with <?php echo $user['username']; ?> |
    <a href="chat_list.php" style="color:white;">Chats</a>
</div>

<!-- CHAT BOX -->
<div class="chat-boxN">

    <!-- MESSAGES -->
    <div class="chat-messagesN">

        <?php while($row = $messages->fetch_assoc()){ ?>

        <div class="messageN <?php echo ($row['sender_id']==$my_id) ? 'sentN' : 'receivedN'; ?>">

            <?php echo htmlspecialchars($row['message']); ?>
            <small style="font-size:10px; display:block; margin-top:5px;">
                <?php echo date("h:i A", strtotime($row['created_at'] ?? 'now')); ?>
            </small>

        </div>

        <?php } ?>

    </div>

    <!-- INPUT -->
    <form method="POST" class="chat-inputN">
        <input type="text" name="message" placeholder="Type message..." required>
        <button name="send">Send</button>
    </form>

</div>