<?php
session_start();
include("config/db.php");

$user_id = $_SESSION['user']['id'] ?? 0;

// GET POSTS (VIDEOS + IMAGES + USER INFO)
$videos = $conn->query("
    SELECT videos.*, users.username, users.profile_pic, users.id as uid
    FROM videos
    JOIN users ON videos.user_id = users.id
    ORDER BY videos.id DESC
");

if(!$videos){
    die("Query Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Workspace</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <a href="index.php">⬅ Back</a>
    <b style="color:white;">Workspace</b>
</div>

<!-- REELS / POSTS -->
<div class="reels-full">

<?php while($vid = $videos->fetch_assoc()){ 
    $video_id = $vid['id'];

    // LIKE COUNT
    $likes = $conn->query("SELECT * FROM video_likes WHERE video_id='$video_id'")->num_rows;

    // CHECK IF USER LIKED
    $liked = $conn->query("
        SELECT * FROM video_likes 
        WHERE video_id='$video_id' AND user_id='$user_id'
    ")->num_rows;
?>

<div class="reel-full">

    <!-- MEDIA (VIDEO OR IMAGE) -->
   <?php if($vid['type'] == 'video'){ ?>

    <video autoplay muted loop controls 
       style="max-width:100%; max-height:100%; object-fit:contain;">
        <source src="uploads/videos/<?php echo $vid['video_path']; ?>">
    </video>

<?php } else { ?>

    <img src="uploads/images/<?php echo $vid['video_path']; ?>" 
     style="max-width:100%; max-height:100%; object-fit:contain;">

<?php } ?>
    <!--caption and profile link-->
    <div class="reel-user">
    <a href="profile.php?id=<?php echo $vid['uid']; ?>" class="user-link">
        
        <img src="uploads/images/<?php echo $vid['profile_pic'] ?? 'default.png'; ?>" class="user-pic">

        <span>@<?php echo $vid['username']; ?></span>

    </a>

    <!-- CAPTION -->
    <div class="caption">
        <?php echo $vid['caption']; ?>
    </div>
</div>
    <!-- RIGHT SIDE ACTIONS -->
    <div class="reel-actions">

        <!-- LIKE -->
        <a href="like_video.php?video_id=<?php echo $video_id; ?>" style="text-decoration:none;">
            <?php echo $liked ? "❤️" : "🤍"; ?>
        </a>
        <span><?php echo $likes; ?></span>

        <!-- COMMENT -->
        <div onclick="toggleComments(<?php echo $video_id; ?>)">💬</div>

    </div>

    <!-- COMMENTS BOX -->
    <div class="comments-box" id="comments-<?php echo $video_id; ?>">

        <?php
        $comments = $conn->query("
            SELECT comments.*, users.username 
            FROM comments
            JOIN users ON comments.user_id = users.id
            WHERE video_id='$video_id'
            ORDER BY comments.id DESC
        ");

        if($comments->num_rows > 0){
            while($c = $comments->fetch_assoc()){ ?>
                <p><b><?php echo $c['username']; ?>:</b> <?php echo $c['comment']; ?></p>
        <?php } } else {
            echo "<p>No comments yet</p>";
        } ?>

        <!-- ADD COMMENT -->
        <form method="POST" action="add_comment.php">
            <input type="hidden" name="video_id" value="<?php echo $video_id; ?>">
            <input type="text" name="comment" placeholder="Write comment..." required>
        </form>

    </div>

</div>

<?php } ?>

</div>

<!-- JS -->
<script>
function toggleComments(id){
    let box = document.getElementById("comments-" + id);

    box.classList.toggle("active");
}
</script>

<script>
const videos = document.querySelectorAll("video");

videos.forEach(video => {
    video.addEventListener("play", () => {
        videos.forEach(v => {
            if(v !== video){
                v.pause();
            }
        });
    });
});
</script>

</body>
</html>