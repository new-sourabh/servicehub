<?php
session_start();
include("config/db.php");

$my_id = $_SESSION['user']['id'];

// GET USERS YOU CHATTED WITH
$users = $conn->query("
    SELECT DISTINCT users.* FROM messages
    JOIN users ON users.id = 
        CASE 
            WHEN sender_id = '$my_id' THEN receiver_id
            ELSE sender_id
        END
    WHERE sender_id = '$my_id' OR receiver_id = '$my_id'
");
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="navbar">
    Your Chats |
    <a href="index.php" style="color:white;">Home</a>
</div>

<!-- 🔥 CHAT LIST -->
<div class="chat-listN">

<?php while($user = $users->fetch_assoc()){ 

    // GET LAST MESSAGE
    $last = $conn->query("
        SELECT * FROM messages 
        WHERE (sender_id='$my_id' AND receiver_id='{$user['id']}')
           OR (sender_id='{$user['id']}' AND receiver_id='$my_id')
        ORDER BY id DESC LIMIT 1
    ")->fetch_assoc();

    $last_msg = $last['message'] ?? "No messages yet";
    $time = isset($last['created_at']) ? date("h:i A", strtotime($last['created_at'])) : "";

?>

<a href="chat.php?user_id=<?php echo $user['id']; ?>" class="chat-itemN">

    <!-- PROFILE -->
    <img src="uploads/images/<?php echo $user['profile_pic'] ?? 'default.png'; ?>">

    <!-- INFO -->
    <div class="chat-infoN">

        <div class="chat-topN">
            <span class="chat-nameN">@<?php echo $user['username']; ?></span>
            <span class="chat-timeN"><?php echo $time; ?></span>
        </div>

        <div class="chat-lastN">
            <?php echo htmlspecialchars(substr($last_msg, 0, 40)); ?>...
        </div>

    </div>

</a>

<?php } ?>

</div>