<?php
session_start();
include("config/db.php");

$video_id = $_GET['id'];
$user_id = $_SESSION['user']['id'];

// CHECK OWNER
$video = $conn->query("SELECT * FROM videos WHERE id='$video_id'")->fetch_assoc();

if($video && $video['user_id'] == $user_id){

    // DELETE FILE FROM FOLDER
    $file = "uploads/videos/" . $video['video_path'];
    if(file_exists($file)){
        unlink($file);
    }

    // DELETE FROM DATABASE
    $conn->query("DELETE FROM videos WHERE id='$video_id'");
}

header("Location: profile.php?id=".$user_id);
exit();