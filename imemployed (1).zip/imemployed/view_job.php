<?php
session_start();
include("config/db.php");

$id = $_GET['id'] ?? 0;

// GET JOB + USER INFO
$job = $conn->query("
    SELECT jobs.*, users.username, users.profile_pic, users.id as uid
    FROM jobs
    JOIN users ON jobs.provider_id = users.id
    WHERE jobs.id='$id'
")->fetch_assoc();

if(!$job){
    echo "Job not found!";
    exit();
}
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="navbar">
    Job Details |
    <a href="index.php" style="color:white;">Home</a>
</div>

<div style="width:500px; margin:30px auto; background:white; padding:20px; border-radius:10px; box-shadow:0 0 10px #ccc;">

    <!-- PROVIDER INFO -->
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">

        <img src="uploads/images/<?php echo $job['profile_pic'] ?? 'default.png'; ?>" 
             style="width:50px; height:50px; border-radius:50%; object-fit:cover;">

        <div>
            <a href="profile.php?id=<?php echo $job['uid']; ?>">
                <b><?php echo $job['username']; ?></b>
            </a>
        </div>

    </div>

    <h2><?php echo $job['title']; ?></h2>

    <p><b>Description:</b><br><?php echo $job['description']; ?></p>

    <p><b>Price:</b> ₹<?php echo $job['price']; ?></p>

    <p><b>Category:</b> <?php echo $job['category']; ?></p>

    <p><b>Location:</b> 📍 <?php echo $job['location']; ?></p>

    <hr>

    <h3>📞 Contact Provider</h3>
    <p><?php echo $job['contact']; ?></p>

</div>