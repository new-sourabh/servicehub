<?php
session_start();
include("config/db.php");

$user_id = $_SESSION['user']['id'] ?? 0;

// SEARCH
$search = "";

if(isset($_GET['search'])){
    $search = $_GET['search'];

    $jobs = $conn->query("
        SELECT jobs.*, users.username, users.profile_pic, users.id as uid
        FROM jobs 
        JOIN users ON jobs.provider_id = users.id
        WHERE jobs.title LIKE '%$search%' 
        OR jobs.category LIKE '%$search%'
        OR jobs.location LIKE '%$search%'
    ");

} else {
    $jobs = $conn->query("
        SELECT jobs.*, users.username, users.profile_pic, users.id as uid
        FROM jobs 
        JOIN users ON jobs.provider_id = users.id
        ORDER BY jobs.id DESC
    ");
}
?>

<link rel="stylesheet" href="assets/css/style.css">

<!-- NAVBAR -->
<div class="navbar">

    <!-- LEFT SIDE (PROFILE) -->
    <div class="nav-left">

        <?php if($user_id){ ?>
            <a href="profile.php?id=<?php echo $user_id; ?>" class="profile-link">

                <img src="uploads/images/<?php echo $_SESSION['user']['profile_pic'] ?? 'default.png'; ?>">

                <span><?php echo $_SESSION['user']['username']; ?></span>

            </a>
        <?php } else { ?>
            <b>ServiceHub</b>
        <?php } ?>

    </div>
    
    <!-- CENTER LOGO -->
    <div class="nav-center">
        <img src="assets/images/logo.png" class="logo">
    </div>

    <!-- RIGHT SIDE -->
    <div class="nav-right">
        <?php if($user_id){ ?>
            <?php echo $_SESSION['user']['name']; ?> |
            <?php if($user_id && $_SESSION['user']['role'] == 'provider'){ ?>
               <a href="provider/dashboard.php">Dashboard</a>
            <?php } ?>           
            <a href="workspace.php">Workspace</a>
            <a href="chat_list.php">Chats</a>
            <a href="follow_list.php?type=following">Following</a>
            <a href="follow_list.php?type=followers">Followers</a>
            <a href="auth/logout.php">Logout</a>
        <?php } else { ?>
            <a href="auth/login.php">Login</a>
            <a href="auth/register.php">Register</a>
        <?php } ?>
    </div>

</div>

<!-- HERO -->
<!-- HERO -->
<div class="hero">
    <h1>Find Trusted Service Providers</h1>

    <form method="GET">
        <input type="text" name="search" placeholder="Search plumber, electrician..." value="<?php echo $search; ?>">
        <button>Search</button>
    </form>

    <!-- 🔥 NEW: CATEGORIES -->
    <div class="categories">
    <span onclick="searchCategory('Electrician')">Electrician</span>
    <span onclick="searchCategory('Plumber')">Plumber</span>
    <span onclick="searchCategory('Developer')">Developer</span>
    <span onclick="searchCategory('Designer')">Designer</span>
    <span onclick="searchCategory('Carpenter')">Carpenter</span>
    </div>
</div>

<!-- JOBS -->
<div class="maincontainerN">

<h2 class="section-title">Available Services</h2>

<div class="jobs-containerN">

<?php if($jobs->num_rows > 0){ ?>

    <?php while($row = $jobs->fetch_assoc()){ ?>

    <div class="job-cardN">

        <div class="providerN">
            <img src="uploads/images/<?php echo $row['profile_pic'] ?? 'default.png'; ?>">
            <span>@<?php echo $row['username']; ?></span>
        </div>

        <h3><?php echo $row['title']; ?></h3>
        <p class="job-descN">
    <?php echo substr($row['description'], 0, 80); ?>...
</p>

        <p>📍 <?php echo $row['location']; ?></p>
        <p>💰 ₹<?php echo $row['price']; ?></p>

        <a href="profile.php?id=<?php echo $row['uid']; ?>" class="btn">View Profile</a>

    </div>

    <?php } ?>

<?php } else { ?>

    <!-- 🔥 EMPTY STATE -->
    <p style="text-align:center; color:#777;">No services found</p>

<?php } ?>

</div>

</div>

<script>
function searchCategory(category){
    window.location.href = "index.php?search=" + category;
}
</script>

<!-- 🔥 FOOTER -->
<div class="footer">
    © 2026 ServiceHub | Developed by Sourabh
</div>