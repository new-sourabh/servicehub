<?php
session_start();
include("config/db.php");

$profile_id = $_GET['id'];
$current_user = $_SESSION['user']['id'] ?? 0;

// USER
$user = $conn->query("SELECT * FROM users WHERE id='$profile_id'")->fetch_assoc();

// FOLLOW COUNTS
$followers = $conn->query("SELECT * FROM follows WHERE following_id='$profile_id'")->num_rows;
$following = $conn->query("SELECT * FROM follows WHERE follower_id='$profile_id'")->num_rows;

// FOLLOW STATUS
$follow_check = $conn->query("SELECT * FROM follows 
    WHERE follower_id='$current_user' AND following_id='$profile_id'")->num_rows;

// SERVICES
$jobs = $conn->query("SELECT * FROM jobs WHERE provider_id='$profile_id'");

// POSTS
$videos = $conn->query("SELECT * FROM videos WHERE user_id='$profile_id' ORDER BY id DESC");
?>

<link rel="stylesheet" href="assets/css/style.css">

<div class="navbar">
    <b>Profile</b>
    <a href="index.php">Home</a>
</div>

<!-- PROFILE HEADER -->
<div class="profile-containerS">

    <div class="profile-left">
        <img src="uploads/images/<?php echo $user['profile_pic'] ?? 'default.png'; ?>" class="profile-imgS">
    </div>

    <div class="profile-rightS">

        <h2>@<?php echo $user['username']; ?></h2>

        <p class="location">📍 <?php echo $user['location']; ?></p>
        <p class="contact">📞 <?php echo $user['phone']; ?></p>

        <!-- STATS -->
        <div class="statsS">
            <span><b><?php echo $followers; ?></b> Connections</span>
            <span><b><?php echo $following; ?></b> Saved</span>
        </div>

        <!-- ACTIONS -->
        <?php if($current_user != $profile_id){ ?>
            <div class="actionsS">
                <a href="follow.php?user_id=<?php echo $profile_id; ?>" class="btn">
                    <?php echo $follow_check ? "Following" : "Follow"; ?>
                </a>

                <a href="chat.php?user_id=<?php echo $profile_id; ?>" class="btn msg">
                    💬 Message
                </a>
            </div>
        <?php } ?>

    </div>

</div>

<!-- EDIT BUTTON -->
<?php if($current_user == $profile_id){ ?>
    <div style="text-align:center;">
        <a href="edit_profile.php" class="btn">✏️ Edit Profile</a>
    </div>
<?php } ?>

<!-- SERVICES -->
<h2 class="section-title">🛠 Services Offered</h2>

<div class="jobs-containerS">

<?php while($job = $jobs->fetch_assoc()){ ?>

<div class="job-cardS">
    <h3><?php echo $job['title']; ?></h3>
    <p class="desc"><?php echo $job['description']; ?></p>
    <p class="priceS">💰 ₹<?php echo $job['price']; ?></p>
</div>

<?php } ?>

</div>

<!-- POSTS -->
<h2 class="section-title">📸 Work Content</h2>

<div class="reels-smallS">

<?php while($vid = $videos->fetch_assoc()){ ?>

<div class="video-boxS">

    <!-- MEDIA -->
    <?php if($vid['type'] == 'video'){ ?>

        <video controls>
            <source src="uploads/videos/<?php echo $vid['video_path']; ?>">
        </video>

    <?php } else { ?>

        <img src="uploads/images/<?php echo $vid['video_path']; ?>">

    <?php } ?>

    <!-- CAPTION -->
    <p class="captionS">
        <?php echo $vid['caption']; ?>
    </p>

    <!-- DELETE -->
    <?php if($current_user == $profile_id){ ?>
        <a href="delete_video.php?id=<?php echo $vid['id']; ?>" 
           class="deleteS"
           onclick="return confirm('Delete this post?')">
           🗑 Delete
        </a>
    <?php } ?>

</div>

<?php } ?>

</div>